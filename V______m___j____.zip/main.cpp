#include<iostream>
#include"VideoGameObjects.h"

using namespace std;

void main() {

	Object someSquare(0, 0);
	Car hondaAcoord(1, 0, 555);

	cout << someSquare;
	cout << hondaAcoord;

}